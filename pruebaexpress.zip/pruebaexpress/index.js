const express = require('express') //importo la libreria
const server = express() //uso la libreria
const PORT = 3000


 //body
    //params  si
    //query  si


    //res/*response*/
    // localhost:3000/users?nombre=pepe&apellido=juarez&nombre=raul
    // console.log(info.nombre);
    // for (let i = 0; i < info.nombre.length; i++) {
    //     const element = info.nombre[i];
    //     console.log(element);

    // }
    // console.log(req.query);





//---------------------------------------------------
//este es el metodo params

/*

server.get('/users/:numero/:numero2', (req ,res ) => {
   
    const info = req.params
    
    console.log(req.params);
    
    const var1 = info.numero
    const var2 = info.numero2
    
    let suma = 0
    let resta = 0
    let multiplicacion =0
    let division = 0

    suma = parseInt(var1) + parseInt(var2) 
    resta = parseInt(var1) - parseInt(var2)
    multiplicacion = parseInt(var1) * parseInt(var2)
    division = parseInt(var1) / parseInt(var2)

    res.send(`${info.numero} es el primer valor y  ${info.numero2} el segundo, su suma es:  ${suma} , su resta es:  ${resta}, su multiplicacion es ${multiplicacion} y su division es ${division} `)
    
})

//las peticiones se pondria algo como localhost:3000/users/44/33

*/

//----------------------------------------------------
//metodo query

/*
server.get('/users', (req,res ) => {

    const info = req.query;
    const num1= parseInt(info.num1);
    const num2= parseInt(info.num2);
    let suma = num1 + num2;
    let resta = num1 - num2;
    let multiplicacion = num1 * num2;
    let division = num1 / num2;


    console.log(info.num1);
    console.log(info.num2);
    console.log(info);
    
    
    res.send(`La suma de los valores ${num1} y ${num2} es igual a  ${suma} ,  su resta es ${resta} , su multiplicacion es ${multiplicacion} y su division es ${division} `);
})
*/
//se enviaria algo como localhost:3000/users?num1=4&num2=5

//----------------------------------------------------

//metodo body

server.use(express.json())

server.post('/users', (req,res) => {

    const info = req.body ;

    console.log (info);
    

    let suma = info.numero1 + info.numero2;
    let resta = info.numero1 - info.numero2;
    let multiplicacion = info.numero1 * info.numero2;
    let division = info.numero1 / info.numero2;


    

    console.log(suma);

    res.send(`la suma de los valores ${info.numero1} y ${info.numero2} es de ${suma} , su resta es ${resta} , su multiplicacion es ${multiplicacion} y su division es ${division}`);


})

//se envia en localhost con el metodo post, en la ventana RAW y JSON, en este caso es algo como
/*
{
"numero1":20,

"numero2" : 10

}

porque se envian arrays completos
*/

//-----------------------------------------------------

//mendoza saca tu proyecto de aca


//esto es para el mensaje de en donde se esta corriendo 
server.listen(PORT, () => {
    console.log(`El server esta corriendo en el puerto ${PORT}`);
})
